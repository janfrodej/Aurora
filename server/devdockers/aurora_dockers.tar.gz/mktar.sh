#!/bin/sh
# This file is part of AURORA, a system to store and manage science data.
#
# AURORA is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
# AURORA is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# AURORA. If not, see <https://www.gnu.org/licenses/>.
#
# script to clean away temp-files before compressing archived version

echo "Please stand in the root of the AURORA Docker-folder. All temporary files will now be removed and the AURORA tar-archive created."
read -p "Hit <ENTER> to continue, CTRL+C to abort..." hitenter

# remove ref-files
rm aurora-common/ref.txt
rm aurora-computer/ref.txt
rm aurora-db/ref.txt
rm aurora-samba/ref.txt
rm aurora-server/ref.txt
rm aurora-web/ref.txt

# remove mk-files
rm mkdist
rm mkdz
rm mkfi
rm mknot

# create tar-archive
tar --exclude=distributions --exclude=notification --exclude=fi -czvf aurora_dockers.tar.gz *
