#!/bin/sh

# script to clean away temp-files before compressing archived version

echo "Please stand in the root of the AURORA Docker-folder. All temporary files will now be removed and the AURORA tar-archive created."
read -p "Hit <ENTER> to continue, CTRL+C to abort..." hitenter

# remove ref-files
rm aurora-common/ref.txt
rm aurora-computer/ref.txt
rm aurora-db/ref.txt
rm aurora-samba/ref.txt
rm aurora-server/ref.txt
rm aurora-web/ref.txt

# remove mk-files
rm mkdist
rm mkdz
rm mkfi
rm mknot

# create tar-archive
tar --exclude=distributions --exclude=notification --exclude=fi -czvf aurora_dockers.tar.gz *
