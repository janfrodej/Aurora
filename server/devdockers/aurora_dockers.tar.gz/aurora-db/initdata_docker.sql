-- Docker-specific, database engine-independent init-data for the 
-- AURORA-database
-- ------------------------------------------------------

--
-- Dumping data for table `ENTITY`
--

LOCK TABLES `ENTITY` WRITE;
/*!40000 ALTER TABLE `ENTITY` DISABLE KEYS */;
INSERT INTO `ENTITY` VALUES (2948,16,1),
   (2949,2948,4),
   (2950,16,1),
   (2951,2950,1);
/*!40000 ALTER TABLE `ENTITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `METADATA`
--

LOCK TABLES `METADATA` WRITE;
/*!40000 ALTER TABLE `METADATA` DISABLE KEYS */;
INSERT INTO `METADATA` VALUES (2948,22,1,'1'),
   (2948,20,1,'2948'),
   (2948,21,1,'Laboratories')
   (2948,24,1,'16'),
   (2949,20,1,'2949'),
   (2949,21,1,'AURORA Docker Internal Computer'),
   (2949,22,1,'4'),
   (2949,24,1,'2948'),
   (2949,31,1,'0'),
   (2949,75,1,'/cygdrive/c/Data'),
   (2949,104,1,'10.0.10.14'),
   (2949,105,1,'10.0.10.14 ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBAei4nyNCoPB+fMxmj8j2GjWhFON8grgk76eZ7Dl6qNrVFpvGs79DfRlFvq+psFqvQTHp5q5vvq25zFNaCvNudc='),
   (2950,20,1,'2950'),
   (2950,21,1,'Research Groups'),
   (2950,22,1,'1'),
   (2950,24,1,'16'),
   (2951,20,1,'2951'),
   (2951,21,1,'Fu Manchus Doom Lab'),
   (2951,22,1,'1'),
   (2951,24,1,'2950');
REPLACE METADATA (entity,metadatakey,metadataidx,metadataval) VALUES (96,108,1,'root');
/*!40000 ALTER TABLE `METADATA` ENABLE KEYS */;
UNLOCK TABLES;

