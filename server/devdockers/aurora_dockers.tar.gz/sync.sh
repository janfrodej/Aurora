#!/bin/sh

# sync file from global into this docker folder
cp system aurora-samba/
cp system aurora-server/
cp system aurora-web/
cp system aurora-computer/
